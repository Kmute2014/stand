const Brevo = require('@getbrevo/brevo');

exports.handler = async (event, context) => {
    // Only allow POST requests
    if (event.httpMethod !== 'POST') {
        return {
            statusCode: 405,
            body: JSON.stringify({ error: 'Method not allowed' })
        };
    }

    try {
        const { name, email, role } = JSON.parse(event.body);

        // Validate required fields
        if (!name || !email || !role) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Missing required fields: name, email, role' })
            };
        }

        // Setup Brevo API client
        const apiInstance = new Brevo.TransactionalEmailsApi();
        const apiKey = process.env.BREVO_API_KEY;

        if (!apiKey) {
            console.error('BREVO_API_KEY not set');
            return {
                statusCode: 500,
                body: JSON.stringify({ error: 'Email service not configured' })
            };
        }

        apiInstance.setApiKey(Brevo.TransactionalEmailsApiApiKeys.apiKey, apiKey);

        // Create welcome email
        const sendSmtpEmail = new Brevo.SendSmtpEmail();
        sendSmtpEmail.subject = '👋 Welcome to StandUpPhelo!';
        sendSmtpEmail.sender = {
            "name": "StandUpPhelo",
            "email": "no-reply@yourdomain.com"
        };
        sendSmtpEmail.to = [{ "email": email }];
        sendSmtpEmail.textContent = `Welcome to StandUpPhelo, ${name.split(' ')[0]}!

You've been added to the team standup system. Your role is: ${role}

You can now log in and submit your daily standups at: https://yourdomain.com/standup

Key features:
- Daily standup submissions (What you did, what you'll do, any blockers)
- Team mood tracking
- Admin blocker alerts
- Response history and analytics

If you have any questions, reach out to your admin.

Best regards,
StandUpPhelo Team`;

        // Send the email
        await apiInstance.sendTransacEmail(sendSmtpEmail);

        console.log(`Welcome email sent successfully to ${email}`);

        return {
            statusCode: 200,
            body: JSON.stringify({
                success: true,
                message: `Welcome email sent to ${name}`
            })
        };

    } catch (error) {
        console.error('Error sending welcome email:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                error: 'Failed to send welcome email',
                details: error.message
            })
        };
    }
};